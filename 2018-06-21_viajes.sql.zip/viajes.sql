-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 21-06-2018 a las 13:08:00
-- Versión del servidor: 10.1.31-MariaDB
-- Versión de PHP: 7.1.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `viajes`
--

DELIMITER $$
--
-- Procedimientos
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `recogeDestino` (IN `ciudad` VARCHAR(20), IN `continente` VARCHAR(20))  BEGIN
    DECLARE zona INT;
CASE   
WHEN continente ="America" THEN SET zona =1; 
WHEN continente ="Europa" THEN SET zona =2; 
WHEN continente ="Asia" THEN SET zona =3; 
WHEN continente ="Oceania" THEN SET zona =4; 
WHEN continente ="Africa" THEN SET zona =5;
END CASE; 
    INSERT INTO destinos(lugar, zona) VALUES (ciudad, zona);
END$$

--
-- Funciones
--
CREATE DEFINER=`root`@`localhost` FUNCTION `tipoViaje` (`precio` FLOAT) RETURNS VARCHAR(10) CHARSET utf8 COLLATE utf8_spanish_ci BEGIN
    DECLARE tipoV VARCHAR(10);
CASE  
WHEN precio<2000 THEN SET tipoV ="normal"; 
WHEN precio<5000 THEN SET tipoV ="bussiness"; 
WHEN precio >5000 THEN SET tipoV="VIP"; 
END CASE; 
        RETURN tipoV;    
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `destinos`
--

CREATE TABLE `destinos` (
  `id` int(5) NOT NULL,
  `lugar` varchar(40) COLLATE utf8_spanish_ci DEFAULT NULL,
  `zona` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `destinos`
--

INSERT INTO `destinos` (`id`, `lugar`, `zona`) VALUES
(1, 'Madrid', 2),
(2, 'Ciudad de MÃ©xico', 1),
(3, 'Hoi chin', 3),
(4, 'ParÃ­s', 2),
(5, 'Mali', 5);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `todoviajes`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `todoviajes` (
`precio` float
,`id_destino` int(5)
,`id` int(5)
,`lugar` varchar(40)
,`zona` int(1)
);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `viajes`
--

CREATE TABLE `viajes` (
  `id` int(5) NOT NULL,
  `id_destino` int(5) NOT NULL,
  `precio` float DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `viajes`
--

INSERT INTO `viajes` (`id`, `id_destino`, `precio`) VALUES
(1, 3, 1258),
(2, 3, 3658),
(3, 3, 3658),
(4, 4, 5898),
(5, 1, 365),
(6, 2, 2365),
(7, 1, 1456),
(8, 4, 6987),
(9, 5, 6958);

-- --------------------------------------------------------

--
-- Estructura para la vista `todoviajes`
--
DROP TABLE IF EXISTS `todoviajes`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `todoviajes`  AS  select `precio` AS `precio`,`id_destino` AS `id_destino`,`destinos`.`id` AS `id`,`destinos`.`lugar` AS `lugar`,`destinos`.`zona` AS `zona` from (`destinos` join `viajes` on((`destinos`.`id` = `id_destino`))) ;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `destinos`
--
ALTER TABLE `destinos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `viajes`
--
ALTER TABLE `viajes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_destino` (`id_destino`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `destinos`
--
ALTER TABLE `destinos`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `viajes`
--
ALTER TABLE `viajes`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `viajes`
--
ALTER TABLE `viajes`
  ADD CONSTRAINT `viajes_ibfk_1` FOREIGN KEY (`id_destino`) REFERENCES `destinos` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
